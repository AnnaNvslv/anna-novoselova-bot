#!/usr/bin/env python3
"""
Telegram бот записи пациентов — Оптика Ginter, Нови-Сад
Оптометрист: Анна Новосёлова
"""

import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# НАСТРОЙКИ — меняй здесь или через переменные окружения
# ─────────────────────────────────────────────
BOT_TOKEN    = os.environ.get("BOT_TOKEN", "")
ADMIN_ID     = int(os.environ.get("ADMIN_ID", "1341961655"))
CALENDAR_URL = os.environ.get("CALENDAR_URL", "https://calendar.google.com/calendar/u/0/appointments/schedules/AcZssZ3WaPb10TPHCz9b1-Bs2z371c7V-dgFJBuXKjM2_LsbSF0vmeg3yp8PvUHnwwXAaVoHOvU325Pw")
FORM_URL     = "https://forms.gle/DvL7qN2JG7JJgy9z6"
ADDRESS      = "Trg Republike, 25 (Рибља пијаца, там, где проходит Ночной Базар)"
MAPS_URL     = "https://maps.app.goo.gl/LJerB2rskqhnhES48"

# ─────────────────────────────────────────────
# УСЛУГИ
# ─────────────────────────────────────────────
SERVICES = {
    "primary": {
        "label":    "🔷 Первичный приём — 3 000 дин.",
        "name":     "первичный приём (подбор очков / КЛ)",
        "duration": "1 час",
        "price":    "3 000 динар (наличными)",
        "tip": (
            "На приём принесите все рецепты, обследования и очки с диоптриями, которые у вас есть.\n\n"
            "За полчаса до приёма прекратите активную зрительную нагрузку — перестаньте работать "
            "за компьютером и телефоном, дайте глазам отдохнуть.\n\n"
            "Если носите контактные линзы — снимите их за 20–30 минут до приёма. "
            "Можно прийти заранее и снять в оптике (возьмите с собой контейнер и жидкость)."
        ),
    },
    "repeat": {
        "label":    "🔷 Повторный приём — 2 000 дин.",
        "name":     "повторный приём",
        "duration": "1 час",
        "price":    "2 000 динар (наличными)",
        "tip": (
            "На приём принесите предыдущие рекомендации и текущие очки.\n\n"
            "За полчаса до приёма дайте глазам отдохнуть от экранов.\n\n"
            "Если носите контактные линзы — снимите их за 20–30 минут до приёма."
        ),
    },
    "consult": {
        "label":    "🔹 Консультация в оптике — 1 000 дин.",
        "name":     "очная консультация в оптике",
        "duration": "30 минут",
        "price":    "1 000 динар (наличными)",
        "tip":      "Возьмите с собой ваши текущие очки, если есть.",
    },
    "help": {
        "label":    "🔹 Помощь с оформлением заказа — бесплатно",
        "name":     "помощь с оформлением заказа",
        "duration": "~15–20 минут",
        "price":    "Бесплатно",
        "tip":      "Уточните заранее наличие свободного окошка — я отвечу в личке @AnnaNvslv.",
    },
}

# Состояния диалога
CHOOSE_SERVICE, WAIT_BOOKED, GET_DATETIME = range(3)


# ─────────────────────────────────────────────
# ХЭНДЛЕРЫ
# ─────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    keyboard = [[InlineKeyboardButton(s["label"], callback_data=key)]
                for key, s in SERVICES.items()]
    await update.message.reply_text(
        "Добро пожаловать! 👋\n\n"
        "Меня зовут Настенька — я помогу записать вас на приём к оптометристу "
        "Анне Новосёловой в Оптику Ginter (Нови-Сад).\n\n"
        "Выберите, пожалуйста, вид приёма:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )
    return CHOOSE_SERVICE


async def service_chosen(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    key = query.data
    service = SERVICES[key]
    context.user_data["service_key"] = key

    keyboard = [
        [InlineKeyboardButton("📅 Открыть календарь записи", url=CALENDAR_URL)],
        [InlineKeyboardButton("✅ Я выбрал(а) время", callback_data="booked")],
    ]
    await query.edit_message_text(
        f"Вы выбрали: *{service['name']}*\n"
        f"⏱ Длительность: {service['duration']}\n"
        f"💰 Стоимость: {service['price']}\n\n"
        "Нажмите *«Открыть календарь записи»*, выберите удобный день и время.\n\n"
        "Когда выберете слот — вернитесь сюда и нажмите *«Я выбрал(а) время»* ✅",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )
    return WAIT_BOOKED


async def patient_booked(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "Отлично! 🎉\n\n"
        "Напишите, пожалуйста, дату и время которое вы выбрали.\n"
        "_Например: 15 мая, 10:00_",
        parse_mode="Markdown",
    )
    return GET_DATETIME


async def receive_datetime(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    dt_text  = update.message.text.strip()
    user     = update.effective_user
    key      = context.user_data.get("service_key", "primary")
    service  = SERVICES[key]
    contact  = f"@{user.username}" if user.username else user.full_name

    # ── Подтверждение пациенту ──────────────────────────────────────────
    await update.message.reply_text(
        f"Вы записаны в Оптику Ginter на *{service['name']}* "
        f"к оптометристу Анне Новосёловой.\n\n"
        f"📅 {dt_text}\n"
        f"⏱ Длительность: {service['duration']}\n"
        f"📍 Адрес: {ADDRESS}\n"
        f"🗺 {MAPS_URL}\n"
        f"💰 Стоимость приёма: {service['price']}\n\n"
        "━━━━━━━━━━━━━━━\n\n"
        f"{service['tip']}\n\n"
        "❤️‍🩹 Если ваши планы изменятся или вы захотите отменить / перенести приём — "
        "сообщите, пожалуйста, заранее.\n\n"
        "Если есть вопросы до приёма — пишите, обсудим.\n\n"
        "До встречи! 🙏",
        parse_mode="Markdown",
    )

    # ── Анкета ──────────────────────────────────────────────────────────
    await update.message.reply_text(
        "И последний шаг — заполните, пожалуйста, короткую анкету, "
        "чтобы я могла подготовиться к вашему приёму заранее:\n\n"
        f"📋 {FORM_URL}"
    )

    # ── Уведомление Анне ────────────────────────────────────────────────
    await context.bot.send_message(
        chat_id=ADMIN_ID,
        text=(
            f"🆕 *Новая запись!*\n\n"
            f"👤 Пациент: {user.full_name}\n"
            f"📱 Контакт: {contact}\n"
            f"🗓 Услуга: {service['name']}\n"
            f"📅 Дата и время: *{dt_text}*\n"
            f"💰 Стоимость: {service['price']}"
        ),
        parse_mode="Markdown",
    )

    logger.info(f"New booking: {contact} | {service['name']} | {dt_text}")
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text(
        "Хорошо, запись прервана. Если захотите записаться — напишите /start 🙂"
    )
    return ConversationHandler.END


async def fallback_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Если пишут что-то вне диалога — предлагаем начать запись."""
    await update.message.reply_text(
        "Чтобы записаться на приём, напишите /start\n\n"
        "По другим вопросам пишите напрямую: @AnnaNvslv 🙂"
    )


# ─────────────────────────────────────────────
# ЗАПУСК
# ─────────────────────────────────────────────

def main() -> None:
    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            CHOOSE_SERVICE: [CallbackQueryHandler(service_chosen)],
            WAIT_BOOKED:    [CallbackQueryHandler(patient_booked, pattern="^booked$")],
            GET_DATETIME:   [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_datetime)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, fallback_message))

    WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "")
    PORT = int(os.environ.get("PORT", 8080))

    if WEBHOOK_URL:
        logger.info(f"Starting webhook on port {PORT}, url: {WEBHOOK_URL}")
        app.run_webhook(
            listen="0.0.0.0",
            port=PORT,
            webhook_url=WEBHOOK_URL,
        )
    else:
        logger.info("Starting polling...")
        app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
